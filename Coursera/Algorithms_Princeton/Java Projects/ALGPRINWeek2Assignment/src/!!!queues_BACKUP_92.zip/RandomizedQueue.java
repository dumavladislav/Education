import java.util.Iterator;
import java.util.NoSuchElementException;

import edu.princeton.cs.algs4.StdRandom;

public class RandomizedQueue<Item> implements Iterable<Item> {
    
    private Node<Item> firstItem;
    private Node<Item> lastItem;
    private int numberOfItems;
    
    private class Node<Item> {
        Item item;
        Node<Item> nextItem;
        Node<Item> prevItem;
    }
    
    public RandomizedQueue() {                 // construct an empty randomized queue
        numberOfItems = 0;
    }
    
    public boolean isEmpty() {                 // is the randomized queue empty?
        if (numberOfItems == 0) return true;
        return false;
    }
    
    public int size() {                        // return the number of items on the randomized queue
        return numberOfItems;
    }

    public void enqueue(Item item) {           // add the item
        if (item == null) throw new IllegalArgumentException();
        Node<Item> oldLast = lastItem;
        lastItem = new Node<Item>();
        lastItem.item = item;
        lastItem.nextItem = null;
        lastItem.prevItem = oldLast;
        if (oldLast != null)    oldLast.nextItem = lastItem;
        if (firstItem == null)  firstItem = lastItem;
        numberOfItems++;
    }

    public Item dequeue() {                    // remove and return a random item
        
        if (isEmpty()) throw new NoSuchElementException();
        
        int randCounter = StdRandom.uniform(numberOfItems)+1;
        Node<Item> tempItem = firstItem;
        for (int i = 0; i < randCounter && i < numberOfItems; i++)
        {
            if (tempItem.nextItem != null)  tempItem = tempItem.nextItem;
        }
        
        Node<Item> oldTemp = tempItem;
        deleteItem(tempItem);

        numberOfItems--;
        return oldTemp.item;
    }
    
    private void deleteItem(Node<Item> item) {
        if (item.prevItem != null)  item.prevItem.nextItem = item.nextItem != null ? item.nextItem : null;
        else    firstItem = null;
        if (item.nextItem != null)  item.nextItem.prevItem = item.prevItem != null ? item.prevItem : null;
        else {
            lastItem = lastItem.prevItem != null ? lastItem.prevItem : null;
        }  
    }

    public Item sample() {                     // return a random item (but do not remove it)
        if (isEmpty()) throw new NoSuchElementException();
        
        int randCounter = StdRandom.uniform(numberOfItems)+1;
        Node<Item> tempItem = firstItem;
        for (int i = 0; i < randCounter && i < numberOfItems; i++)
        {
            if (tempItem.nextItem != null)  tempItem = tempItem.nextItem;
        }
        
        return tempItem.item;
    }

    public Iterator<Item> iterator() {         // return an independent iterator over items in random order
        return new RandomizedQueueIterator();
    }
    
    private class RandomizedQueueIterator implements Iterator<Item> {
        
        Node<Item> current = firstItem;
        
        public boolean hasNext() {
            if (current != null) return true;
            return false;
        }
        
        public void remove() {
            throw new UnsupportedOperationException();
        }
        
        public Item next() {
            if (!hasNext()) throw new NoSuchElementException();
            Node<Item> oldCurrent = current;
            current = current.nextItem;
            return oldCurrent.item;        
        }
        
    }

    public static void main(String[] args) {   // unit testing (optional)
        
        RandomizedQueue<Integer> randQueue = new RandomizedQueue<Integer>();
        /*
        randQueue.enqueue(1);
        randQueue.enqueue(2);
        randQueue.enqueue(3);
        randQueue.enqueue(4);
        randQueue.enqueue(5);
        randQueue.enqueue(6);
        randQueue.enqueue(7);
        randQueue.enqueue(8);
        
        System.out.println(randQueue.dequeue());
        System.out.println(randQueue.dequeue());
        System.out.println(randQueue.dequeue());
        System.out.println(randQueue.dequeue());
        System.out.println(randQueue.dequeue());
        
        System.out.println("REMAINING SIZE = " + randQueue.size());        
        */
        
        System.out.println(randQueue.dequeue());
    }
}
